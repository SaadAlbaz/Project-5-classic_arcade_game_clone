frontend-nanodegree-arcade-game
===============================
## How to start the game
1. unzip the file.
2. open index.html on your browser
3. Enjoy playing

### How to win
Move the player using the arrows on your keyboard, and try to reach the water side by not colliding with the bugs